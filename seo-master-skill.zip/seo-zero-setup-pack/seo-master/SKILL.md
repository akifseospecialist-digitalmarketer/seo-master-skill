---
name: seo-master
description: >
  Single entry point for SEO tasks in this pack. Use whenever the user
  mentions SEO, search rankings, organic traffic, site/page audits, keyword
  research, content briefs, backlinks/link building, E-E-A-T, featured
  snippets, topic clusters, or asks to write/improve a page for search — even
  if they don't say "SEO" explicitly (e.g. "why isn't this page ranking",
  "help me plan a blog post", "should I build links to this page"). This pack
  is fully self-sufficient: every skill below researches live via search/page
  fetch, with no data exports, API keys, or connectors required. Consult this
  skill FIRST to pick the right one before invoking anything else.
license: MIT
metadata:
  category: seo
  version: "1.0.0"
---

# SEO Master (Zero-Setup Pack): Router for 11 Self-Sufficient SEO Skills

This skill doesn't do SEO work itself — it picks which skill in this pack
should handle the request, then hands off. Every skill here works with
nothing but web search and page fetch: no DataForSEO, no Google Search
Console, no Semrush/Ahrefs. That also means none of them can report exact
search volumes, historical trends, or a true backlink-count — they read the
live SERP and live pages instead. Say so plainly if the user asks for a
number this pack can't produce (e.g. "monthly search volume for X"),
rather than estimating one and presenting it as real data.

## Task → skill map

| User wants | Skill |
|---|---|
| Audit a specific page's SEO (technical + content + competitive) | `page-audit` |
| Plan a brand-new article (brief, outline, on-page targets) | `content-brief` |
| Decide whether/how to target a specific keyword | `keyword-deep-dive` |
| Plan a hub-and-spoke topic cluster for a new content area | `topic-cluster-planning` |
| Find why a page ranks but isn't top-3 (missing entities/subtopics) | `semantic-gap-analysis` |
| Score a page's Experience/Expertise/Authority/Trust signals | `eeat-audit` |
| Build a link-acquisition strategy | `linkbuilding` |
| Pull first-party expertise from a subject-matter expert before writing | `expert-interview` |
| Win a featured snippet for a keyword already ranking 1–5 | `featured-snippet-optimizer` |
| Write a complete new SEO article | `write-content` |
| Rewrite/refresh an underperforming page | `improve-content` |

## Common combos (chain these rather than asking the user to sequence manually)

- **New article:** `expert-interview` (if a SME is available) →
  `content-brief` → `write-content`.
- **Underperforming page:** `page-audit` → `semantic-gap-analysis` →
  `improve-content`.
- **New content area from scratch:** `topic-cluster-planning` → run
  `content-brief` → `write-content` for each spoke.
- **Already ranking, want more clicks:** `featured-snippet-optimizer` (if
  ranking 1–5) or `eeat-audit` + `improve-content` (if ranking lower and
  quality is the likely blocker).

## If nothing fits cleanly

If the request needs real numeric data this pack can't produce (search
volume, keyword difficulty scores, an actual backlink count, GSC clicks/
impressions, Core Web Vitals field data), say so directly, give your best
qualitative read instead, and note that a connector-backed SEO toolset (e.g.
DataForSEO, Google Search Console, Semrush, Ahrefs) would be needed for the
real numbers. Otherwise, handle it directly or ask one clarifying question
rather than forcing it into the nearest skill.
