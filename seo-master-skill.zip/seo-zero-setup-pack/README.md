# Zero-Setup SEO Skill Pack for Claude

Twelve skills (11 workers + 1 router) that give Claude a complete SEO
workflow — page audits, content briefs, keyword research, link-building
strategy, E-E-A-T scoring, featured-snippet optimization, and full article
writing/rewriting.

**No API keys, no connectors, no data exports required.** Every skill
researches live by having Claude search Google and fetch pages itself. That's
the trade-off: you get zero setup, but no exact search-volume numbers,
historical trends, or true backlink counts. If you need those, you'll want a
connector-backed toolset (DataForSEO, Google Search Console, Semrush, or
Ahrefs) alongside this pack — this pack does not include that.

## What's inside

| Skill | What it does |
|---|---|
| `seo-master` | Router — always consulted first, picks the right skill below |
| `page-audit` | Full audit of one URL: fetches it, Googles the primary keyword, reads top 3 competitors, scores 7 dimensions |
| `content-brief` | Writer-ready brief for a new article — Googles the keyword, reads top 10, maps the content gap |
| `keyword-deep-dive` | 90-day ranking plan for a specific keyword — intent, SERP read, competitor read |
| `topic-cluster-planning` | Hub-and-spoke content architecture for a new topic area |
| `semantic-gap-analysis` | What's missing from a page vs. top-ranking competitors |
| `eeat-audit` | Scores Experience/Expertise/Authority/Trust on a page |
| `linkbuilding` | Phase-appropriate link-acquisition tactics from a 9-playbook library |
| `expert-interview` | Extracts first-party expertise from a SME before writing |
| `featured-snippet-optimizer` | Rewrites a section to win a snippet you're not yet holding |
| `write-content` | Writes a full SEO article (includes an anti-AI-slop ruleset) |
| `improve-content` | Rewrites an underperforming existing page |

## Install

Drop all 12 folders into your Claude skills directory so each one sits
alongside its own `SKILL.md`, e.g.:

```
your-skills-folder/
  seo-master/SKILL.md
  page-audit/SKILL.md
  content-brief/SKILL.md
  keyword-deep-dive/SKILL.md
  topic-cluster-planning/SKILL.md
  semantic-gap-analysis/SKILL.md
  eeat-audit/SKILL.md
  linkbuilding/SKILL.md
  expert-interview/SKILL.md
  featured-snippet-optimizer/SKILL.md
  write-content/SKILL.md
  improve-content/SKILL.md
```

Exactly how you register a skills folder depends on which Claude product
you're using (claude.ai project skills, Claude Code, etc.) — check that
product's docs for the specific install step.

## Usage

Just ask normally — "audit this page," "write me a blog post about X,"
"help me plan a topic cluster for Y." `seo-master` reads the request and
routes to the right skill (or chains a few together) automatically; you
don't need to name a skill by hand.

## License

**TBD — see `LICENSE_TODO.md` before publishing this repo publicly.**
